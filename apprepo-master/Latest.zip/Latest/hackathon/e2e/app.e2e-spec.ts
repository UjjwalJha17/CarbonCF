import { CarbonDashboardAngularPage } from './app.po';

describe('material-dashboard-angular App', () => {
  let page: CarbonDashboardAngularPage;

  beforeEach(() => {
    page = new CarbonDashboardAngularPage();
  });

  it('should display message saying app works', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('app works!');
  });
});
